create
    definer = root@localhost procedure sp_fail()
BEGIN
    DECLARE `_rollback` BOOL DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET `_rollback` = 1;
    START TRANSACTION;
    select HeshPas,UserName,LastNameUser,UserNickname from DataUser left join LogPasUser on DataUser.PassIdUser=LogPasUser.Id;
    select HeshPas,AdminName,LastnameAdmin,AdminNickname from AdminTable left join LogPasUser on LogPasUser.Id=AdminTable.PassIdAdmin;
    IF `_rollback` THEN
        ROLLBACK;
    ELSE
        COMMIT;
    END IF;
END;

